package entities

type Personality struct {
	ID           string `json:"id" gorm:"size:512"`
	Type_person  string `json:"type_personality"`
	Information1 string `json:"information_1"`
	Information2 string `json:"information_2"`
	Information3 string `json:"information_3"`
	Information4 string `json:"information_4"`
	Information5 string `json:"information_5"`
}
