package handler

import (
	"career-paths/entities"
	"career-paths/interfaces"
	"net/http"

	"github.com/google/uuid"
	"github.com/labstack/echo/v4"
)

type testUserHandler struct {
	s interfaces.TestUserService
}

func NewTestUserController(testUserService interfaces.TestUserService) interfaces.TestUserHandler {
	return &testUserHandler{
		s: testUserService,
	}
}

// CreateTestUser implements interfaces.TestUserHandler
func (h *testUserHandler) CreateTestUser(c echo.Context) error {
	testUser := &entities.TestUser{
		ID: uuid.New().String(),
	}
	if err := c.Bind(&testUser); err != nil {
		return c.JSON(http.StatusBadRequest, map[string]interface{}{
			"message": err.Error(),
			"status":  false,
			"code":    http.StatusBadRequest,
		})
	}

	fail := h.s.CreateTestUserService(testUser)
	if fail != nil {
		return c.JSON(fail.Code, map[string]interface{}{
			"message": fail.Message,
			"status":  false,
			"code":    fail.Code,
		})
	}

	return c.JSON(http.StatusCreated, map[string]interface{}{
		"code":    http.StatusCreated,
		"message": "Create Test User Successfully!!!!",
	})
}

// GetTestUserPerID implements interfaces.TestUserHandler
func (h *testUserHandler) GetTestUserPerID(c echo.Context) error {
	id := c.Param("id")

	testUsers, fail := h.s.GetTestUserPerIDService(id)

	if fail != nil {
		return c.JSON(fail.Code, map[string]interface{}{
			"code":    fail.Code,
			"message": fail.Message,
		})
	}

	response := make([]map[string]interface{}, len(testUsers))
	for i, testUser := range testUsers {
		response[i] = map[string]interface{}{
			"id":          testUser.ID,
			"name_id":     testUser.NameID,
			"test_result": testUser.TestResult,
			"first_name":  testUser.FirstName,
			"last_name":   testUser.LastName,
		}
	}
	return c.JSON(http.StatusOK, map[string]interface{}{
		"code":    http.StatusOK,
		"message": "Successfully get test User by ID",
		"result":  testUsers,
	})
}

// GetAllTestUsers implements interfaces.TestUserHandler
func (h *testUserHandler) GetAllTestUsers(c echo.Context) error {
	testUsers, fail := h.s.GetAllTestUsersService()
	if fail != nil {
		return c.JSON(fail.Code, map[string]interface{}{
			"code":    fail.Code,
			"message": fail.Message,
		})
	}

	response := make([]map[string]interface{}, len(testUsers))
	for i, testUser := range testUsers {
		response[i] = map[string]interface{}{
			"id":          testUser.ID,
			"name_id":     testUser.NameID,
			"test_result": testUser.TestResult,
			"first_name":  testUser.FirstName,
			"last_name":   testUser.LastName,
			"email":       testUser.Email,
		}
	}

	return c.JSON(http.StatusOK, map[string]interface{}{
		"code":    http.StatusOK,
		"message": "Successfully get all test users",
		"result":  response,
	})
}
